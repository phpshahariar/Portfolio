
<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Hello Shahariar Ikbal....!</h2>
<br/>
<b>You have a new lead from <br>
    <span>Name: {!! $name !!} | Email: {!! $email !!}</span><br>
    via My Portfolio</b>
<br/>
<p>{!! $mage !!}</p>
</body>

</html>