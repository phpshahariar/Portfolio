<?php $__env->startSection('body'); ?>
    <br/>
    <h1><?php echo e(Session::get('message')); ?></h1>
    <form name="editAboutForm" class="form-horizontal" action="<?php echo e(url('/update-about')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="well">
            <div class="form-group">
                <label  class="col-sm-3 control-label">Designation</label>
                <div class="col-sm-7">
                    <input name="designation_title" value="<?php echo e($abouts->designation_title); ?>" type="text" class="form-control">
                    <input name="designation_id" value="<?php echo e($abouts->id); ?>" type="hidden" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('designation_title') ? $errors->first('designation_title') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">Description</label>
                <div class="col-sm-7">
                    <textarea name="description" class="form-control textarea"><?php echo e($abouts->description); ?></textarea>
                    <span style="color: red"> <?php echo e($errors->has('description') ? $errors->first('description') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Publication Status</label>
                <div class="col-sm-7">
                    <select class="form-control" name="publication_status">
                        <option>---Select Publication Status---</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-7">
                    <button type="submit" name="btn" class="btn btn-block btn-primary">Update About Info</button>
                </div>
            </div>
        </div>
    </form>
    <script>
        document.forms['editAboutForm'].elements['publication_status'].value="<?php echo e($abouts->publication_status); ?>";
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>