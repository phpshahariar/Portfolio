
<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Hello Shahariar Ikbal....!</h2>
<br/>
<b>You have a new lead from <br>
    <span>Name: <?php echo $name; ?> | Email: <?php echo $email; ?></span><br>
    via My Portfolio</b>
<br/>
<p><?php echo $mage; ?></p>
</body>

</html>