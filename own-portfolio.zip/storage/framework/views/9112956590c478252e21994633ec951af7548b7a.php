<?php $__env->startSection('body'); ?>
    <br/>
    <div class="row">
        <div class="col-lg-12">
            <?php if($message = Session::get('message')): ?>
                <h1 class="page-header"><?php echo e($message); ?></h1>
            <?php endif; ?>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    DataTables Advanced Tables
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                        <tr>
                            <th>SL NO</th>


                            <th>First Office Name</th>
                            <th>Project Description</th>


                            <th>Second Office Name</th>
                            <th>Project Description</th>


                            <th>Third Office Name</th>
                            <th>Project Description</th>


                            <th>Publication Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <?php $i=1;?>
                        <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr class="odd gradeX">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($experience->first_office); ?></td>
                                <td><?php echo e($experience->first_project); ?></td>

                                <td><?php echo e($experience->second_office); ?></td>
                                <td><?php echo e($experience->second_project); ?></td>

                                <td><?php echo e($experience->third_office); ?></td>
                                <td><?php echo e($experience->third_project); ?></td>

                                <td><?php echo e($experience->publication_status ==1 ? 'Published' : 'Unpublished'); ?> </td>
                                <td>
                                    <?php if($experience->publication_status ==1): ?>
                                        <a href="<?php echo e(url('/unpublished-experience/'.$experience->id)); ?>" name="btn" class="btn btn-xs btn-success" title="Update Experience">
                                            <span class="glyphicon glyphicon-arrow-up"></span>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/published-experience/'.$experience->id)); ?>" name="btn" class="btn btn-xs btn-warning" title="Update Experience">
                                            <span class="glyphicon glyphicon-arrow-down"></span>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(url('/edit-experience/'.$experience->id)); ?>" name="btn" class="btn btn-xs btn-primary" title="Edit Experience">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>
                                    <a href="<?php echo e(url('/delete-experience/'.$experience->id)); ?>" name="btn" class="btn btn-xs btn-danger" title="Remove Experience" onclick="return confirm('Are You Sure You Want to Remove This!')">
                                        <span class="glyphicon glyphicon-remove"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                    <!-- /.table-responsive -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>