<?php $__env->startSection('body'); ?>
    <br/>
    <h1><?php echo e(Session::get('message')); ?></h1>
    <form class="form-horizontal" action="<?php echo e(url('/new-contact')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="well">

            <div class="form-group">
                <label  class="col-sm-3 control-label">Our Description</label>
                <div class="col-sm-7">
                    <textarea name="description" class="form-control"></textarea>
                    <span style="color: red"> <?php echo e($errors->has('category_name') ? $errors->first('category_name') : ' '); ?></span>
                </div>
            </div>

            <div class="form-group">
                <label  class="col-sm-3 control-label">Location</label>
                <div class="col-sm-7">
                    <input name="location" type="text" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('category_name') ? $errors->first('category_name') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">E-mail</label>
                <div class="col-sm-7">
                    <input name="email" type="text" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('category_name') ? $errors->first('category_name') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">Phone Number</label>
                <div class="col-sm-7">
                    <input type="number" name="number" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('university_description') ? $errors->first('university_description') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Publication Status</label>
                <div class="col-sm-7">
                    <select class="form-control" name="publication_status">
                        <option>---Select Publication Status---</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-7">
                    <button type="submit" name="btn" class="btn btn-block btn-primary">Save Blog Info</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>