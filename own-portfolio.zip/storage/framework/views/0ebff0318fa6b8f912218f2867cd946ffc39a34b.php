<?php $__env->startSection('body'); ?>
    <br/>
    <h1><?php echo e(Session::get('message')); ?></h1>
    <form class="form-horizontal" action="<?php echo e(url('/new-resume')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h1 style="color: green; text-align: center">Resume Information</h1>
        <hr/>
        <div class="well">
            <div class="form-group">
                <label  class="col-sm-3 control-label">University Year</label>
                <div class="col-sm-7">
                    <input name="university_year" type="number" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('passing_year') ? $errors->first('passing_year') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">University Course</label>
                <div class="col-sm-7">
                    <input name="course_name" type="text" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('course_name') ? $errors->first('course_name') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">University Name</label>
                <div class="col-sm-7">
                    <input name="university_name" type="text" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('course_name') ? $errors->first('course_name') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">University Course Description</label>
                <div class="col-sm-7">
                    <textarea name="course_description" class="form-control"></textarea>
                    <span style="color: red"> <?php echo e($errors->has('course_description') ? $errors->first('course_description') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">College Year</label>
                <div class="col-sm-7">
                    <input name="college_year" class="form-control" type="number">
                    <span style="color: red"> <?php echo e($errors->has('college_year') ? $errors->first('college_year') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">College Course</label>
                <div class="col-sm-7">
                    <input name="college_course" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('college_course') ? $errors->first('college_course') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">College Name</label>
                <div class="col-sm-7">
                    <input name="college_name" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('college_name') ? $errors->first('college_name') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">College Course Description</label>
                <div class="col-sm-7">
                    <textarea name="college_description" class="form-control"></textarea>
                    <span style="color: red"> <?php echo e($errors->has('college_description') ? $errors->first('college_description') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">School Year</label>
                <div class="col-sm-7">
                    <input name="school_year" class="form-control" type="number">
                    <span style="color: red"> <?php echo e($errors->has('college_year') ? $errors->first('college_year') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">School Course</label>
                <div class="col-sm-7">
                    <input name="school_course" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('school_course') ? $errors->first('school_course') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">School Name</label>
                <div class="col-sm-7">
                    <input name="school_name" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('school_name') ? $errors->first('school_name') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">School Course Description</label>
                <div class="col-sm-7">
                    <textarea name="school_description" class="form-control"></textarea>
                    <span style="color: red"> <?php echo e($errors->has('school_description') ? $errors->first('school_description') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">First Joining Date</label>
                <div class="col-sm-7">
                    <input name="first_join" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('first_join') ? $errors->first('first_join') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">First Designation</label>
                <div class="col-sm-7">
                    <input name="first_designation" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('first_designation') ? $errors->first('first_designation') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">First Office</label>
                <div class="col-sm-7">
                    <input name="first_office" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('first_office') ? $errors->first('first_office') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">First Project Description</label>
                <div class="col-sm-7">
                    <textarea name="first_description" class="form-control"></textarea>
                    <span style="color: red"> <?php echo e($errors->has('first_description') ? $errors->first('first_description') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Second Joining Date</label>
                <div class="col-sm-7">
                    <input name="second_join" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('second_join') ? $errors->first('second_join') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Second Designation</label>
                <div class="col-sm-7">
                    <input name="second_designation" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('second_designation') ? $errors->first('second_designation') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Second Office</label>
                <div class="col-sm-7">
                    <input name="second_office" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('second_office') ? $errors->first('second_office') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">Second Project Description</label>
                <div class="col-sm-7">
                    <textarea name="second_description" class="form-control"></textarea>
                    <span style="color: red"> <?php echo e($errors->has('first_description') ? $errors->first('first_description') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Current Joining Date</label>
                <div class="col-sm-7">
                    <input name="current_join" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('current_join') ? $errors->first('current_join') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Current Designation</label>
                <div class="col-sm-7">
                    <input name="current_designation" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('current_designation') ? $errors->first('current_designation') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Current Office</label>
                <div class="col-sm-7">
                    <input name="current_office" class="form-control" type="text">
                    <span style="color: red"> <?php echo e($errors->has('current_office') ? $errors->first('current_office') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">Current Project Description</label>
                <div class="col-sm-7">
                    <textarea name="current_description" class="form-control"></textarea>
                    <span style="color: red"> <?php echo e($errors->has('current_description') ? $errors->first('current_description') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Publication Status</label>
                <div class="col-sm-7">
                    <select class="form-control" name="publication_status">
                        <option>---Select Publication Status---</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-7">
                    <button type="submit" name="btn" class="btn btn-block btn-primary">Save Resume Info</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>