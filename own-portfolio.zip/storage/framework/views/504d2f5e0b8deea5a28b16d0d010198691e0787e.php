<?php $__env->startSection('body'); ?>
    <br/>
    <h1><?php echo e(Session::get('message')); ?></h1>
    <form name="editProfileForm" class="form-horizontal" action="<?php echo e(url('/update-profile')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="well">
            <div class="form-group">
                <label  class="col-sm-3 control-label">Profile Name</label>
                <div class="col-sm-7">
                    <input name="name" value="<?php echo e($logos->name); ?>" type="text" class="form-control">
                    <input name="name_id" value="<?php echo e($logos->id); ?>" type="hidden" class="form-control">
                </div>
            </div>

            <div class="form-group">
                <label  class="col-sm-3 control-label">Profile Title</label>
                <div class="col-sm-7">
                    <input name="title" value="<?php echo e($logos->title); ?>" type="text" class="form-control">

                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Profile Picture</label>
                <div class="col-sm-7">
                    <input name="image"  type="file" accept="image/*" >
                    <img src="<?php echo e(asset($logos->image)); ?>" alt="" height="80" width="80"/>

                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Publication Status</label>
                <div class="col-sm-7">
                    <select class="form-control" name="publication_status">
                        <option>---Select Publication Status---</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-7">
                    <button type="submit" name="btn" class="btn btn-block btn-primary">Update Profile Info</button>
                </div>
            </div>
        </div>
    </form>
    <script>
        document.forms['editProfileForm'].elements['publication_status'].value='<?php echo e($logos->publication_status); ?>';
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>