<?php $__env->startSection('body'); ?>
    <br/>
    <h1><?php echo e(Session::get('message')); ?></h1>
    <form name="editInfoForm" class="form-horizontal" action="<?php echo e(url('/update-info')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="well">
            <div class="form-group">
                <label  class="col-sm-3 control-label">Owner Name</label>
                <div class="col-sm-7">
                    <input name="heading_name" value="<?php echo e($backend->heading_name); ?>" type="text" class="form-control">
                    <input name="heading_id" value="<?php echo e($backend->id); ?>" type="hidden" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('heading_name') ? $errors->first('heading_name') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Title</label>
                <div class="col-sm-7">
                    <input name="title" value="<?php echo e($backend->title); ?>" type="text" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('title') ? $errors->first('title') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Sub-Title</label>
                <div class="col-sm-7">
                    <input name="sub_title" value="<?php echo e($backend->sub_title); ?>"  type="text" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('sub_title') ? $errors->first('sub_title') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">E-mail</label>
                <div class="col-sm-7">
                    <input name="email" value="<?php echo e($backend->email); ?>" type="text" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('email') ? $errors->first('email') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Phone</label>
                <div class="col-sm-7">
                    <input name="phone" value="<?php echo e($backend->phone); ?>" type="number" class="form-control">
                    <span style="color: red"> <?php echo e($errors->has('phone') ? $errors->first('phone') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-3 control-label">Address</label>
                <div class="col-sm-7">
                    <textarea name="own_address" class="form-control"><?php echo e($backend->own_address); ?></textarea>
                    <span style="color: red"> <?php echo e($errors->has('own_address') ? $errors->first('own_address') : ' '); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label  class="col-sm-3 control-label">Publication Status</label>
                <div class="col-sm-7">
                    <select class="form-control" name="publication_status">
                        <option>---Select Publication Status---</option>
                        <option value="1">Published</option>
                        <option value="0">Unpublished</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-3 col-sm-7">
                    <button type="submit" name="btn" class="btn btn-block btn-primary">Update Home Info</button>
                </div>
            </div>
        </div>
        <script>
            document.forms['editInfoForm'].elements['publication_status'].value="<?php echo e($backend->publication_status); ?>";
        </script>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>