<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BgImage extends Model
{
    //
}
